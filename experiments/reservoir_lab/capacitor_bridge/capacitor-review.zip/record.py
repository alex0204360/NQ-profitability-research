from pathlib import Path
import runpy, sys
p=Path(__file__).parent/'experiments/reservoir_lab/capacitor_bridge'
sys.path.insert(0,str(p))
runpy.run_path(str(p/'forward.py'),run_name='__main__')
