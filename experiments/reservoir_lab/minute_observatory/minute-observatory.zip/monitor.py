from pathlib import Path
import runpy
runpy.run_path(str(Path(__file__).parent/'experiments/reservoir_lab/minute_observatory/observer.py'), run_name='__main__')
